package com.example.cungu.myapplication4;

import android.Manifest;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class photoActivity extends AppCompatActivity implements AdapterView.OnItemClickListener,AlbumAdapater.InnerItemOnClickListener{
    private AlbumAdapater albumAdapater;
    List<PictureInfo> pictureInfos;
    private ListView listView;
    private Button button2;
    private static int REQUEST_CAMERA=3;
    String path;
    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_photo);
        listView=findViewById(R.id.listView);
        if(checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)!= PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},1);
        }
        pictureInfos=new ArrayList<PictureInfo>();
        String path1= Environment.getExternalStorageDirectory()+"/DCIM/Camera/";
        List<String> filesAllName=new ArrayList<String>();
        filesAllName=getFilesAllName(path1);
        for(int i=0;i<(filesAllName.size());i++){
            PictureInfo pictureInfo=new PictureInfo(getFileName(filesAllName.get(i).toString()),filesAllName.get(i).toString());
            pictureInfos.add(pictureInfo);
        }
        albumAdapater=new AlbumAdapater(this,pictureInfos);
        albumAdapater.setInnerItemOnClickListener(this);
        listView.setAdapter(albumAdapater);
        listView.setOnItemClickListener(this);
        albumAdapater.notifyDataSetChanged();
        path="";
        button2=(Button)findViewById(R.id.button2);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

    }

    /**
     * 通过完整文件名（包含路径）切出文件名（不包含路径）
     * @param pathandname
     * @return
     */
    public String getFileName(String pathandname){
        int start=pathandname.lastIndexOf("/");
        int end=pathandname.lastIndexOf(".");
        if (start!=-1 && end!=-1) {
            return pathandname.substring(start+1, end);
        }
        else {
            return null;
        }
    }
    public  ArrayList<String> getFilesAllName(String path) {
        File file=new File(path);
        File[] files=file.listFiles();
        if (files == null){
            Log.e("error","空目录");
            return null;
        }
        ArrayList<String> s = new ArrayList<>();
        for(int i =0;i<files.length;i++){
            s.add(files[i].getAbsolutePath());
        }
        return s;
    }


    public void onClick(View view) {
        //将拍的照片直接保存到path
        if (Build.VERSION.SDK_INT>=Build.VERSION_CODES.N){
            path=Environment.getExternalStorageDirectory()+"/DCIM/Camera/"+MyDate.formatDate(new Date())+".jpg";
            takePhotoBiggerThan7((new File(path).getAbsolutePath()));
            PictureInfo pictureInfo=new PictureInfo(getFileName(path),path);
            pictureInfos.add(pictureInfo);
            Toast.makeText(this, pictureInfos.size()+"  vg",Toast.LENGTH_SHORT).show();
            albumAdapater.notifyDataSetChanged();
        }else {
            path=Environment.getExternalStorageDirectory()+"/DCIM/111/"+MyDate.formatDate(new Date())+".jpg";
            takePhotoBiggerThan7((new File(path).getAbsolutePath()));
            // 指定拍照意图
            Intent openCameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            // 加载路径图片路径
            Uri mUri = Uri.fromFile(new File(Environment.getExternalStorageDirectory()+"/DCIM/Camera/"+MyDate.formatDate(new Date())+".jpg"));
            // 指定存储路径，这样就可以保存原图了
            openCameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, mUri);
            startActivityForResult(openCameraIntent, REQUEST_CAMERA);
        }

    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        ListView list = (ListView) parent;
        PictureInfo s= (PictureInfo) list.getItemAtPosition(position);
        Intent intent=new Intent();
        intent.setClass(photoActivity.this, DisplayActivity.class);
        intent.putExtra("path",s.getPath());
        startActivity(intent);
    }

    @Override
    public void itemClick(View view) {
        int position= (int) view.getTag();
    }
    @Override
    protected  void onActivityResult(int requestCode,int resultCode,Intent data) {
        if(data==null)
            return;
        Bundle bundle = data.getExtras();
        if (requestCode == REQUEST_CAMERA) {
            Bitmap b = BitmapFactory.decodeFile(path);
            PictureInfo pictureInfo=new PictureInfo(getFileName(path),path);
            pictureInfos.add(pictureInfo);
            Toast.makeText(this, pictureInfos.size()+"  vg",Toast.LENGTH_SHORT).show();
            albumAdapater.notifyDataSetChanged();
        }
    }
    //    /**
//     * 保存bitmap到SD卡
//     * @param bitmap
//     * @param imagename
//     */
//    public String saveBitmapToSDCard(Bitmap bitmap, String imagename) {
//        String path = Environment.getExternalStorageDirectory()+"/DCIM/111/" + imagename + ".jpg";
//        FileOutputStream fos = null;
//        try {
//            fos = new FileOutputStream(path);
//            if (fos != null) {
//                bitmap.compress(Bitmap.CompressFormat.JPEG, 90, fos);
//                fos.close();
//            }
//            pictureInfos.add(new PictureInfo("111",path));
//
//            return path;
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return null;
//    }
    private void takePhotoBiggerThan7(String absolutePath) {
        Uri mCameraTempUri;
        try {
            ContentValues values = new ContentValues(1);
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpg");
            values.put(MediaStore.Images.Media.DATA, absolutePath);
            mCameraTempUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                    | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            if (mCameraTempUri != null) {
                intent.putExtra(MediaStore.EXTRA_OUTPUT, mCameraTempUri);
                intent.putExtra(MediaStore.EXTRA_VIDEO_QUALITY, 1);
            }
            startActivityForResult(intent, REQUEST_CAMERA);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
