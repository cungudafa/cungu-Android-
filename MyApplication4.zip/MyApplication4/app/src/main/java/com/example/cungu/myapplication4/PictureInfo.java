package com.example.cungu.myapplication4;

public class PictureInfo {
    String date;

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    String path;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    String name;
    PictureInfo(String name, String path){
        this.path=path;
        this.name=name;
    }
}
