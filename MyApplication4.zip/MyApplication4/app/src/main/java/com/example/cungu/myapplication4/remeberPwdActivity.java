package com.example.cungu.myapplication4;

import android.content.Intent;
import android.preference.PreferenceManager;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

public class remeberPwdActivity extends AppCompatActivity {

    private SharedPreferences pref;
    private SharedPreferences.Editor editor;

    private EditText accountEdit;
    private EditText passwordEdit;
    private Button login;
    private CheckBox savePassword;
    private CheckBox autoLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_remeber_pwd);

        pref = PreferenceManager.getDefaultSharedPreferences(this);
        accountEdit = (EditText) findViewById(R.id.account);
        passwordEdit = (EditText) findViewById(R.id.password);
        savePassword = (CheckBox) findViewById(R.id.savePassword);
        autoLogin = (CheckBox) findViewById(R.id.autologin);
        login = (Button) findViewById(R.id.login);
        passwordEdit.setInputType(InputType.TYPE_CLASS_TEXT
                | InputType.TYPE_TEXT_VARIATION_PASSWORD);//隐式密码
        boolean isRemember = pref.getBoolean("savePassword", false);

        if (isRemember) {
            // 将账号和密码都设置到文本框中,下一次进入不如再输密码啦
            String account = pref.getString("account", "");
            String password = pref.getString("password", "");
            accountEdit.setText(account);
            passwordEdit.setText(password);
            savePassword.setChecked(true);
        }

        login.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                String account = accountEdit.getText().toString();
                String password = passwordEdit.getText().toString();
                if (account.equals("student") && password.equals("123456")) {
                    editor = pref.edit();
                    if (savePassword.isChecked()) { // 检查复选框是否被选中
                        editor.putBoolean("savePassword", true);
                        editor.putString("account", account);
                        editor.putString("password", password);
                    } else {
                        editor.clear();
                    }
                    editor.commit();
                    Toast.makeText(remeberPwdActivity.this, "Login Success！", Toast.LENGTH_SHORT).show();
                    //Intent intent = new Intent(remeberPwdActivity.this, MainActivity.class);//跳转
                    //startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(remeberPwdActivity.this, "account or password is invalid", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
