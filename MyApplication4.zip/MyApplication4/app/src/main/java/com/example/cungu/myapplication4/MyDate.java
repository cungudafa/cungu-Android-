package com.example.cungu.myapplication4;

import java.text.SimpleDateFormat;
import java.util.Date;

public class MyDate {
    public static String formatDate(Date date){
        if(date==null){
            return "";
        }
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return format.format(date);
    }

    public static String formatDate(long time){
        Date date = new Date(time);
        SimpleDateFormat format = new SimpleDateFormat("yyyy年MM月dd日 HH点mm分ss");
        return format.format(date);
    }

    public static String formatDate(String time){
        Date date = new Date(Long.valueOf(time));
        SimpleDateFormat format = new SimpleDateFormat("yyyy年MM月dd日 HH点mm分ss");
        return format.format(date);
    }

    public static boolean isNumber(String str){
        boolean isOk = false;
        try {
            Integer.valueOf(str);
            isOk = true;
        } catch (NumberFormatException e) {
            isOk = false;
            e.printStackTrace();
        }
        return isOk;
    }
}
