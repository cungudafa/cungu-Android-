package com.example.cungu.myapplication4;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.ThumbnailUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.File;
import java.util.List;

public class AlbumAdapater extends BaseAdapter implements View.OnClickListener{
    private List pictureInfos;
    private Context stuContext;
    private InnerItemOnClickListener innerItemOnClickListener;
    public AlbumAdapater(Context context, List list){
        this.pictureInfos=list;
        this.stuContext=context;
    }
    @Override
    public void onClick(View v) {
        innerItemOnClickListener.itemClick(v);
    }

    @Override
    public int getCount() {
        return pictureInfos.size();
    }

    @Override
    public Object getItem(int position) {
        return pictureInfos.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View stuView=View.inflate(stuContext,R.layout.list_view,null);
        //获得item的每个子元素
        TextView name=stuView.findViewById(R.id.name);
        ImageView picture=stuView.findViewById(R.id.picture);
        //将数据源的一项数据和Item的子元素绑定
        PictureInfo pictureInfo= (PictureInfo) pictureInfos.get(position);
        name.setText(pictureInfo.getName());
        File mFile=new File(pictureInfo.getPath());
        if(mFile.exists()){
            picture.setImageBitmap(getImageThumbnail(pictureInfo.getPath(), 70, 70));

        }

        return stuView;
    }
    interface InnerItemOnClickListener{
        abstract void itemClick(View view);
    }
    public void setInnerItemOnClickListener(InnerItemOnClickListener listener){
        this.innerItemOnClickListener=listener;
    }

    /**
     * 传入一个文件，返回一个Bitmap的缩略图，防止图片过大导致OOM
     * @param imagePath
     * @param width
     * @param height
     * @return
     */
    public static Bitmap getImageThumbnail(String imagePath, int width, int height) {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true; //关于inJustDecodeBounds的作用将在下文叙述
        Bitmap bitmap = BitmapFactory.decodeFile(imagePath, options);
        int h = options.outHeight;//获取图片高度
        int w = options.outWidth;//获取图片宽度
        int scaleWidth = w / width; //计算宽度缩放比
        int scaleHeight = h / height; //计算高度缩放比
        int scale = 1;//初始缩放比
        if (scaleWidth < scaleHeight) {//选择合适的缩放比
            scale = scaleWidth;
        } else {
            scale = scaleHeight;
        }
        options.inSampleSize = scale;
        // 重新读入图片，读取缩放后的bitmap，注意这次要把inJustDecodeBounds 设为 false
        options.inJustDecodeBounds = false;
        bitmap = BitmapFactory.decodeFile(imagePath, options);
        // 利用ThumbnailUtils来创建缩略图，这里要指定要缩放哪个Bitmap对象
        bitmap = ThumbnailUtils.extractThumbnail(bitmap, width, height,ThumbnailUtils.OPTIONS_RECYCLE_INPUT);
        return bitmap;
    }







}
