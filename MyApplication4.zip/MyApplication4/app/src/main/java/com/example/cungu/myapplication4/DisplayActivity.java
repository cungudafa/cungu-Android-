package com.example.cungu.myapplication4;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.io.File;

public class DisplayActivity extends AppCompatActivity {
    private ImageView imageView;
    String path;
    private Button button1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);
        imageView=findViewById(R.id.image);
        button1=(Button)findViewById(R.id.button1);
        Bundle bundle=getIntent().getExtras();
        path= (String) bundle.get("path");
        File mFile=new File(path);
        if(mFile.exists()){
            Bitmap bitmap= BitmapFactory.decodeFile(path);
            imageView.setImageBitmap(bitmap);
            imageView.setScaleType(ImageView.ScaleType.FIT_XY);
        }
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent();
                intent.setClass(DisplayActivity.this,photoActivity.class );//返回
                startActivity(intent ) ;
            }
        });
    }
    public boolean deleteFile(String filePath) {
        File file = new File(filePath);
        if (file.isFile() && file.exists()) {
            return file.delete();
        }
        return false;
    }
    public void onClick(View view) {
        deleteFile(path);
        Intent intent=new Intent();
        intent.setClass(this,MainActivity.class);
        startActivity(intent);
    }
}