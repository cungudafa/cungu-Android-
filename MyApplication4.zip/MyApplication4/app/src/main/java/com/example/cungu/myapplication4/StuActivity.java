package com.example.cungu.myapplication4;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.net.URI;

public class StuActivity extends AppCompatActivity implements View.OnClickListener {
    private TextView texts;
    private Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stu);
        texts=(TextView)findViewById(R.id.texts);
        button=(Button)findViewById(R.id.button);
        button.setOnClickListener(this);

    }
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.button:
                search();
                break;
        }
    }
    public void insert(){
        ContentResolver resolver = getContentResolver();// 获取ContentResolver
        Uri uri = Uri.parse("content://provider/student");
        // 插入表中数据
        ContentValues values = new ContentValues();
        values.put("id", "6");
        values.put("name", "test");
        values.put("sex", "男");
        values.put("age", "20");
        values.put("academy", "信息科学与工程");
        values.put("major", "物联网工程");
        values.put("date", "19980101");
        // 通过ContentResolver 根据URI 向ContentProvider中插入数据
        Uri result=resolver.insert(uri, values);
        String n=result.getPath();
        Toast.makeText(this, n, Toast.LENGTH_SHORT).show();
        Toast.makeText(this, "插入成功！", Toast.LENGTH_SHORT).show();
    }
    public void search(){
        ContentResolver resolver=getContentResolver();
        Uri uri=Uri.parse("content://Student");
        Cursor cursor=resolver.query(uri,null,null,null,null);
        if(cursor!=null)
            while (cursor.moveToNext()){
                String id=cursor.getString(cursor.getColumnIndex("id"));
                String name=cursor.getString(cursor.getColumnIndex("name"));
                String sex=cursor.getString(cursor.getColumnIndex("sex"));
                String age=cursor.getString(cursor.getColumnIndex("age"));
                String academy=cursor.getString(cursor.getColumnIndex("academy"));
                String major=cursor.getString(cursor.getColumnIndex("major"));
                String date=cursor.getString(cursor.getColumnIndex("date"));
                texts.append("\n"+id+" "+name+" "+sex+"  "+age+"  "+academy+"  "+major+"  "+date+"  ");
            }
    }

}
