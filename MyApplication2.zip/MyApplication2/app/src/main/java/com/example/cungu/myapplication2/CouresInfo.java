package com.example.cungu.myapplication2;

import java.io.Serializable;

public class CouresInfo implements Serializable {
    private String name;
    private String couresName;

    public CouresInfo(String n,String m)
    {
        name = n;
        couresName = m;
    }

    public String getCouresName() {
        return couresName;
    }

    public String getName() {
        return name;
    }

    public void setCouresName(String couresName) {
        this.couresName = couresName;
    }

    public void setName(String name) {
        this.name = name;
    }

}
