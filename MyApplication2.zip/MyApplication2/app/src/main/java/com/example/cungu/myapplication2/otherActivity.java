package com.example.cungu.myapplication2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class otherActivity extends AppCompatActivity implements View.OnClickListener,AdapterView.OnItemClickListener,
        StuAdapter.InnerItemOnClickListener {

    List<Map<String, Object>> stuMap = new ArrayList<Map<String, Object>>();
    List<String> names = new ArrayList<String>();
    List<String> majors = new ArrayList<String>();
    ListView studentlist;
    private StuAdapter stuAdapater;
    private List<StuInfo> students;
    private Button Btn_add;

    Bundle bundle = getIntent().getExtras();
    //ArrayList<StuInfo> students = (ArrayList<StuInfo>) bundle.get("students");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_other);
        studentlist = (ListView) findViewById(R.id.studentlist);
        initlistView();//声明数组
        //获取传值
        for (int i = 0; i < students.size(); i++) {
            Map<String, Object> map = new HashMap<String, Object>();
            String n = students.get(i).getName();
            names.add(n);
            map.put("name", names.get(i));
            String m = students.get(i).getMajor();
            majors.add(m);
            map.put("major", majors.get(i));
            stuMap.add(map);
        }

        String[] key = {"name", "major"};
        int[] value = {R.id.name, R.id.major};
        SimpleAdapter simpleAdapter = new SimpleAdapter(this, stuMap, R.layout.stu_list, key, value);
        studentlist.setAdapter(simpleAdapter);

    }
    private void initlistView() {
        List<Map<String, Object>> stuMap = new ArrayList<Map<String, Object>>();
        String[] names = new String[100];
        String[] majors = new String[100];
    }


    @Override
    public void onClick(View v) {

    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void itemClick(View view) {

    }
}
      /*  stu_show = (TextView) findViewById(R.id.stu_show);

        Bundle bundle=getIntent().getExtras();
        ArrayList<StuInfo> students=(ArrayList<StuInfo>)bundle.get("students");

        for (StuInfo s : students) {
            //String list="\t 姓名:"+"\t 性别: "+"\t 专业: "+"\t 年龄 "+"\n";
            String stuInfo =  s.getName() +"   \t   " + s.getSex()+ " \t    " + s.getMajor() +" \t   "+s.getAge()+"\n" ;
            stu_show.append(stuInfo);
        }
        */
