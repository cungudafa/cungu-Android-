package com.example.cungu.myapplication2;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Main2Activity extends AppCompatActivity implements View.OnClickListener{
    private Button button1;
    private Button button2;
    private Button button3;
    private Button button4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        button1 =(Button)findViewById(R.id.button_call );
        button2 =(Button)findViewById(R.id.button_camera );
        button3 =(Button)findViewById(R.id.button_compass  );
        button4 =(Button)findViewById(R.id.button_chat );
        button1.setOnClickListener(this);
        button2.setOnClickListener(this);
        button3.setOnClickListener(this);
        button4.setOnClickListener(this);
    }
    public void onClick(View view ){
        Intent intent=new Intent();
        switch (view.getId() ) {
            case R.id.button_call ://打电话
                //intent.setAction(intent.ACTION_DIAL ) ;
                intent.setClass(this,callActivity.class );
                startActivity(intent ) ;
                break;
            case R.id.button_camera ://照相机
                //intent.setAction("android.media.action.STILL_IMAGE_CAMERA") ;
                intent.setClass(this,cameraActivity.class );
                break;
            case R.id.button_compass ://地图
                Uri uri=Uri.parse("geo:39.899533,116.036476");
                intent.setAction(intent.ACTION_VIEW ) ;
                intent.setData(uri);
                break;
            case R.id.button_chat://发短信
                intent.setClass(this,chatActivity.class );
                startActivity(intent ) ;
                break;
        }
        startActivity(intent);
    }
}
