package com.example.cungu.myapplication2;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class chatActivity extends AppCompatActivity implements View.OnClickListener{
    Button button_chat;
    Button button_phonebook;
    EditText phoneNum;//电话号码
    EditText message;//要发送的文本
    String username,usernumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
        button_chat = (Button) findViewById(R.id.button_chat);
        button_phonebook = (Button) findViewById(R.id.button_phonebook);
        message = (EditText) findViewById(R.id.message);
        phoneNum = (EditText) findViewById(R.id.phoneNum);
        button_phonebook.setOnClickListener(this);
        button_chat.setOnClickListener(this);
    }
    public void onClick(View view ){
        String phoneNumber=phoneNum.getText().toString() ;
        switch (view.getId() ) {
            case R.id.button_chat ://发送短信
                if(phoneNumber.length() == 0){
                    Toast.makeText(chatActivity.this,"输入不能为空",Toast.LENGTH_SHORT).show(); //弹出一个自动消失的提示框
                    return;
                }else{
                    String p = phoneNum.getText().toString();
                    String m = message.getText().toString();
                    Uri smstoUri = Uri.parse("smsto:"); // 解析地址
                    Intent intent = new Intent(Intent.ACTION_VIEW,smstoUri);
                    intent.putExtra("address",p); // 没有电话号码的话为默认的，即显示的时候是为空的
                    intent.putExtra("sms_body",m); // 设置发送的内容
                    intent.setType("vnd.android-dir/mms-sms");
                    startActivity(intent);
                }break;
            case R.id.button_phonebook://调用电话本
                startActivityForResult(new Intent(
                        Intent.ACTION_PICK, ContactsContract.Contacts.CONTENT_URI), 0);
                break;
        }
    }
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {
            ContentResolver reContentResolverol = getContentResolver();
            Uri contactData = data.getData();
            Cursor cursor = managedQuery(contactData, null, null, null, null);
            cursor.moveToFirst();
            username = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
            String contactId = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts._ID));
            Cursor phone = reContentResolverol.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    null,
                    ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = " + contactId,
                    null, null);
            while (phone.moveToNext()) {
                usernumber = phone.getString(phone.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                phoneNum.setText(usernumber + " (" + username + ")");
                phoneNum.setFocusable(true);
                phoneNum.setFocusableInTouchMode(true);
                phoneNum.requestFocus();//光标设置
            }
        }
    }

       /* button_chat.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                String p = text.getText().toString();
                String m = message.getText().toString();
                Uri smstoUri = Uri.parse("smsto:"); // 解析地址
                Intent intent = new Intent(Intent.ACTION_VIEW,smstoUri);
                intent.putExtra("address",p); // 没有电话号码的话为默认的，即显示的时候是为空的
                intent.putExtra("sms_body",m); // 设置发送的内容
                intent.setType("vnd.android-dir/mms-sms");
                startActivity(intent);
            }
        });
       }
    */
}