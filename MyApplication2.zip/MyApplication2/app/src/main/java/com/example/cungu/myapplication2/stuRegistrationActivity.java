package com.example.cungu.myapplication2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class stuRegistrationActivity extends AppCompatActivity implements View.OnClickListener{

    Button button_add;
    Button button_send;
    AutoCompleteTextView stu_name;
    RadioGroup rg_gender;
    Spinner stu_major;
    private ArrayList<String> majors=new ArrayList<String>();
    private ArrayAdapter<String> arr_adapter;
    EditText stu_age;
    ArrayList<StuInfo> studentList=new ArrayList<StuInfo>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stu_registration);
        button_add = (Button) findViewById(R.id.button_add);
        button_send = (Button) findViewById(R.id.button_send);
        stu_name  = (AutoCompleteTextView) findViewById(R.id.stu_name);
        stu_major = (Spinner) findViewById(R.id.stu_major);
        stu_age=(EditText) findViewById(R.id.stu_age);
        rg_gender=(RadioGroup)findViewById(R.id.rg_gender);
        button_add.setOnClickListener(this);
        button_send.setOnClickListener(this);


        //输入时自动提示
        String[] name={"张三","李四","wang"};
        ArrayAdapter<String> arrayAdapter2=new ArrayAdapter(this,R.layout.au_textview,name);
        stu_name.setAdapter(arrayAdapter2);

        //获得major
        majors.add("物联网工程");
        majors.add("计算机科学");
        majors.add("通信工程  ");
        arr_adapter= new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, majors);
        //设置样式
        arr_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //加载适配器
        stu_major.setAdapter(arr_adapter);
    }
    //正则表达式判断是否为数字
    private  boolean isDigtal(String num){
        return num.matches("[0-9]{1,}");
    }
    @Override
    public void onClick(View view) {
        Intent intent = new Intent();
        switch (view.getId()) {
            case R.id.button_add:
                if(stu_name.length() == 0){
                    stu_name.setError("不能为空!");
                }
                if(stu_age.length()==0){
                    stu_age.setError("不能为空!");
                    //Toast.makeText(stuActivity.this,"输入不能为空!",Toast.LENGTH_SHORT).show(); //弹出一个自动消失的提示框
                    //return;
                }else {
                    String name=stu_name.getText().toString() ;//
                    String sex=getCheckedRadioInfo(rg_gender);//返回性别
                    String major=stu_major.getSelectedItem().toString();
                    String age=stu_age.getText().toString();
                    if (!isDigtal(age.toString())){
                        stu_age.setError("只能为数字!");
                    }
                    StuInfo stu=new StuInfo(name,major);
                    //StuInfo stu=new StuInfo(name,sex,major,age);//字符串
                    studentList.add(stu);//studentList添加学生
                    if(stu!=null&&isDigtal(age.toString())){
                        Toast.makeText(this,"添加完成！",Toast.LENGTH_SHORT).show();
                        return;
                    }
                }
                break;
            case R.id.button_send:
                if(studentList.isEmpty()) return;
                intent.putExtra("students",studentList);//传值
                intent.setClass(this, otherActivity.class);
                startActivity(intent);
                break;
        }
    }
    //获得RadioGroup中返回的sex性别值(String类型)
    private String getCheckedRadioInfo(RadioGroup radioGroup) {
        String sex="";
        int num=radioGroup.getChildCount();
        for(int i=0;i<num;i++){
            RadioButton rd=(RadioButton)radioGroup.getChildAt(i);
            if(rd.isChecked()){
                sex=rd.getText().toString();
                break;
            }
        }
        return sex;
    }
}
