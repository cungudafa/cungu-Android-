package com.example.cungu.myapplication2;

import android.graphics.Color;
import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.BackgroundColorSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.text.style.StyleSpan;
import android.text.style.SuperscriptSpan;
import android.widget.TextView;

import java.util.ArrayList;

public class other2Activity extends AppCompatActivity {
    TextView stu_show2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_other2);
        stu_show2 = (TextView) findViewById(R.id.stu_show2);

        Bundle bundle=getIntent().getExtras();//获得传值
        ArrayList<CouresInfo> coures=(ArrayList<CouresInfo>)bundle.get("coures");

        for (CouresInfo c: coures) {
            String list1 = c.getName()+" 已选课程有: " + "\n";
            String couresInfo = c.getCouresName() + "\n";
            //=========================字体样式设置============================================
            SpannableString text1=new SpannableString(list1);
            //设置前景色
            ForegroundColorSpan forcolor=new ForegroundColorSpan(Color.parseColor("#ef7a82"));
            text1.setSpan(forcolor,0,text1.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);//定位
            //设置背景色
            BackgroundColorSpan back=new BackgroundColorSpan(Color.parseColor("#80ffffff"));
            text1.setSpan(back,0,text1.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);//定位
            //设置文字相对大小
            RelativeSizeSpan relativeSizeSpan=new RelativeSizeSpan(1.5f);
            text1.setSpan(relativeSizeSpan,0,c.getName().length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            //设置上标
            SuperscriptSpan superscriptSpan=new SuperscriptSpan();
            text1.setSpan(superscriptSpan,0,c.getName().length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            //设置粗体和斜体
            StyleSpan styleSpan=new StyleSpan(Typeface.BOLD);
            StyleSpan styleSpan1=new StyleSpan(Typeface.ITALIC);
            text1.setSpan(styleSpan,0,c.getName().length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            text1.setSpan(styleSpan1,0,c.getName().length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            //================================================================================
            stu_show2.append(text1);
            stu_show2.append(couresInfo);
        }
    }
}
