package com.example.cungu.myapplication2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class stuActivity extends AppCompatActivity implements View.OnClickListener{
    Button button_1;
    Button button_2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stu);
        button_1 = (Button) findViewById(R.id.button_1);
        button_2 = (Button) findViewById(R.id.button_2);
        button_1.setOnClickListener(this);
        button_2.setOnClickListener(this);
    }
    @Override
    public void onClick(View view) {
        Intent intent = new Intent();
        switch (view.getId()) {
            case R.id.button_1:
                intent.setClass(this,stuRegistrationActivity.class);
                startActivity(intent);
                break;
            case R.id.button_2:
                intent.setClass(this,ChoseCouresActivity.class);
                startActivity(intent);
                break;
        }
    }

}
