package com.example.cungu.myapplication2;

import java.io.Serializable;

public class StuInfo implements Serializable {
    private String name;
    private String major;
   // private String age;
    //private String sex;

    public StuInfo(String n,String i)//,String i,String j)
    {
        name=n;
     //   sex=m;
        major=i;
      //  age=j;
    }

    public String getMajor() {
        return major;
    }
    public String getName() {
        return name;
    }
  //  public String getAge(){ return age;}
   // public String getSex(){return sex;}

  //  public void setAge(String age) {this.age = age;    }

   // public void setSex(String sex) { this.sex=sex; }

    public void setMajor(String major) {
        this.major = major;
    }


    public void setName(String name) {
        this.name = name;
    }
}
