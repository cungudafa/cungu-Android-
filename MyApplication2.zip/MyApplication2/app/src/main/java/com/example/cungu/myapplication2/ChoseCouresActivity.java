package com.example.cungu.myapplication2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import java.util.ArrayList;

public class ChoseCouresActivity extends AppCompatActivity implements View.OnClickListener{
        Button button_add;
        Button button_send;
        AutoCompleteTextView stu_name;
        LinearLayout check_project;
        ArrayList<CouresInfo> couresList=new ArrayList<CouresInfo>();

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_chose_coures);
            button_add = (Button) findViewById(R.id.button_add);
            button_send = (Button) findViewById(R.id.button_send);
            stu_name  = (AutoCompleteTextView) findViewById(R.id.stu_name);
            check_project=(LinearLayout)findViewById(R.id.check_project);
            button_add.setOnClickListener(this);
            button_send.setOnClickListener(this);
            //输入时自动提示
            String[] arr={"张三","李四","wang"};
            ArrayAdapter<String> arrayAdapter=new ArrayAdapter(this,R.layout.au_textview,arr);
            stu_name.setAdapter(arrayAdapter);
        }
        @Override
        public void onClick(View view) {
            Intent intent = new Intent();
            switch (view.getId()) {
                case R.id.button_add:
                    if(stu_name.length() == 0){
                        stu_name.setError("不能为空!");
                        //Toast.makeText(stuActivity.this,"输入不能为空!",Toast.LENGTH_SHORT).show(); //弹出一个自动消失的提示框
                        //return;
                    }else {
                        String name=stu_name.getText().toString() ;
                        String couresName=getCheckedBoxInfo(check_project);
                        CouresInfo coures=new CouresInfo(name,couresName);
                        couresList.add(coures);
                        if(coures!=null){
                            Toast.makeText(this,"添加完成！",Toast.LENGTH_SHORT).show();
                            return;
                        }
                    }
                    break;
                case R.id.button_send:
                    if(couresList.isEmpty()) return;
                    intent.putExtra("coures",couresList);
                    intent.setClass(this, other2Activity.class);
                    startActivity(intent);
                    break;
            }
        }
        //
    private String getCheckedBoxInfo(LinearLayout check_project) {
        String couresName="";
        int num=check_project.getChildCount();
        for(int i=0;i<num;i++){
            CheckBox checkBox=(CheckBox)check_project.getChildAt(i);
            if(checkBox.isChecked()){
                couresName+=checkBox.getText().toString()+"\n";
            }
        }
        return couresName;
    }
    //自定义动态checkbox的内容
    public void initcheckbox(String[] array) {
        for(String s:array){
            CheckBox checkBox=(CheckBox) View.inflate(this,R.layout.au_checkboxlist,null);
            checkBox.setText(s);
            check_project.addView(checkBox);
        }
    }
}
