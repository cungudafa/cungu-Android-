package com.example.cungu.myapplication3;

import java.io.Serializable;

public class StuInfo implements Serializable {
    private String name;
    private String major;

    public StuInfo(String n, String m)
    {
        name=n;
        major=m;
    }

    public String getMajor() {
        return major;
    }
    public String getName() {
        return name;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public void setName(String name) {
        this.name = name;
    }
}
