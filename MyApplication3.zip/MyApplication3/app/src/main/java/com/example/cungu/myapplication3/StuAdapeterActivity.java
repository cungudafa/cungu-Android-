package com.example.cungu.myapplication3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class StuAdapeterActivity extends AppCompatActivity implements View.OnClickListener,AdapterView.OnItemClickListener,
        StuAdapter.InnerItemOnClickListener {

    private ListView studentList;
    private StuAdapter stuAdapater;
    private List<StuInfo> students;
    private Button Btn_add;
    String name,major;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stu_adapeter);
        studentList=(ListView) findViewById(R.id.studentslist);
        Btn_add=(Button)findViewById(R.id.btn_add);
        Btn_add.setOnClickListener(this);
         /*
          构造一组学生的集合
         */
        students=new ArrayList<>();
      /*  StuInfo s1=new StuInfo("易烊千玺","电子工程");
        StuInfo s2=new StuInfo("王源","物联网工程");
        StuInfo s3=new StuInfo("王俊凯","计算机科学");
        students.add(s1);
        students.add(s2);
        students.add(s3);
        */
        //获取传值
        Bundle bundle = getIntent().getExtras();
        ArrayList<StuInfo> students4=(ArrayList<StuInfo>) bundle.get("students");
        for(StuInfo s:students4){
            name=s.getName();
            major=s.getMajor();
            StuInfo s4=new StuInfo(name,major);
            students.add(s4);
        }
        stuAdapater=new StuAdapter(this,students);
        ///为配置器设置一个自定义的item内部控件的点击监听
        stuAdapater.setOnInnerItemOnClickListener(this);
        ///listview设置适配器
        studentList.setAdapter(stuAdapater);
        ///LISTVIEW设置选项监听
        studentList.setOnItemClickListener(this);
    }
    ///列表的每个item的点击事件
    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        ListView list = (ListView) adapterView;
        StuInfo s= (StuInfo) list.getItemAtPosition(i);
        Toast.makeText(this, s.getName(),Toast.LENGTH_SHORT).show();
    }
    ///内部控件的点击事件方法
    @Override
    public void itemClick(View view) {
        int position= (int) view.getTag();
        switch (view.getId()) {
            case R.id.edit:
                Intent intent=new Intent();
                Toast.makeText(this, "编辑" + name, Toast.LENGTH_SHORT).show();
                intent.putExtra("name", name);
                students.remove(position);
                stuAdapater.notifyDataSetChanged();//适配器更新数据
                setResult(0, intent);
                finish();
                intent.setClass(this,StuListOperationActivity.class);//添加学生
                startActivity(intent);
                break;
            case R.id.delete:
                students.remove(position);//删除集合
                stuAdapater.notifyDataSetChanged();//适配器更新数据
                Toast.makeText(this, "删除" + position, Toast.LENGTH_SHORT).show();
                break;
        }
    }
    //添加学生btn_add按钮
    @Override
    public void onClick(View v) {
        Intent intent=new Intent();
        switch (v.getId()) {
            case R.id.btn_add:
                intent.setClass(this, StuListOperationActivity.class);//计算器线性1
                startActivity(intent);
                break;
        }
    }
}
