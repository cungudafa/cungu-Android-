package com.example.cungu.myapplication3;

import android.graphics.drawable.Drawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ImageSpan;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class biaoqingActivity extends AppCompatActivity {
    EditText et_biaoqing;
    Button btn_input;
    Button btn_save;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_biaoqing);
        et_biaoqing=(EditText) findViewById(R.id.et_biaoqing);
        btn_input=(Button) findViewById(R.id.btn_input);
        btn_save=(Button) findViewById(R.id.btn_save);
        btn_input.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SpannableString spannableString=new SpannableString("t");
                Drawable drawable=getResources().getDrawable(R.drawable.emoji01);
                drawable.setBounds(0,0,drawable.getIntrinsicWidth(),drawable.getIntrinsicHeight());
                ImageSpan imageSpan=new ImageSpan(drawable);
                spannableString.setSpan(imageSpan,0,1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                et_biaoqing.append(spannableString);
            }
        });

    }
}
