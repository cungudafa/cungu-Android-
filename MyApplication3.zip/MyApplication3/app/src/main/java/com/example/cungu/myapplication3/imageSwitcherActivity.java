package com.example.cungu.myapplication3;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageSwitcher;
import android.widget.ImageView;
import android.widget.ViewSwitcher;

public class imageSwitcherActivity extends AppCompatActivity implements View.OnClickListener,ViewSwitcher.ViewFactory {
    private ImageSwitcher is_1;
    private Button btn_next;
    private Button btn_previous;
    private int image[]={R.drawable.tian1,R.drawable.tian2,R.drawable.tian3,R.drawable.movieback};//图片的id数组
    private int imageIndex=0;//图片显示序列号

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_switcher);
        is_1=(ImageSwitcher) findViewById(R.id.is_1);
        btn_next=(Button) findViewById(R.id.btn_next);
        btn_previous=(Button) findViewById(R.id.btn_previous);
        btn_previous.setOnClickListener(this);
        btn_next.setOnClickListener(this);
        init(); //设置Factory
    }

    @Override
    public void onClick(View view) {
        if (view.getId()==R.id.btn_next){
            imageIndex++;
            if(imageIndex>3){
                imageIndex=0;
            }
            is_1.setInAnimation(this,R.anim.left_in);
            is_1.setOutAnimation(this,R.anim.right_out);
        }else if(view.getId()==R.id.btn_previous){
            imageIndex--;
            if(imageIndex<0){
                imageIndex=image.length-1;
            }
            is_1.setInAnimation(this,R.anim.right_in);
            is_1.setOutAnimation(this,R.anim.left_out);
        }
        is_1.setImageResource(image[imageIndex]);
    }

    @Override
    public View makeView() {//实现viewFactory接口.生成imageview
        ImageView imageView=new ImageView(this);
        return imageView;
    }
    private void init(){//初始化imageSwitch
        is_1.setFactory(this);
        is_1.setImageResource(image[imageIndex]);
    }
}

