package com.example.cungu.myapplication3;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;

public class buttonActivity extends AppCompatActivity implements View.OnClickListener,View.OnFocusChangeListener {
    private com.example.cungu.myapplication3.CircleImageView btn_1;
    private Button btn_2;
    private Button btn_3;
    private int value=1;//1表示增加,-1表示减少{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_button);
        btn_1=(com.example.cungu.myapplication3.CircleImageView) findViewById(R.id.btn_1);
        btn_2=(Button) findViewById(R.id.btn_2);
        btn_3=(Button) findViewById(R.id.btn_3);
        //btn_1焦点变蓝
        btn_1.setOnFocusChangeListener(this);//焦点变化监听
        //btn_2点击
        btn_2.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                // TODO Auto-generated method stub
                switch (event.getAction()) {

                    case MotionEvent.ACTION_DOWN://按下变蓝
                        btn_2.setBackgroundResource(R.drawable.shape_button_blue);
                        break;
                    case MotionEvent.ACTION_UP:
                        btn_2.setBackgroundResource(R.drawable.shape_button_cool);
                        break;
                }
                return true;
            }

        });
        //btn_3点击变大
        btn_3.setOnClickListener(this);
        //btn_3.setOnTouchListener(this);//触摸监听
        btn_3.setOnFocusChangeListener(this);//焦点变化监听
    }

    @Override
    public void onClick(View view) {
        Button btn=(Button)view;//强转为按钮
        int screenWidth=getWindow().getWindowManager().getDefaultDisplay().getWidth();//屏幕宽度
        if(value==1&&btn.getWidth()>screenWidth-35){
            value=-1;
        }else if(value==-1&&btn.getWidth()<300){
            value=1;
        }
        btn.setWidth(btn.getWidth()+(int)(btn.getWidth()*0.1*value));
        btn.setHeight(btn.getHeight()+(int)(btn.getHeight()*0.1*value));
    }

    @Override
    public void onFocusChange(View view, boolean hasFocus) {
        if(hasFocus){//存在焦点
            view.setBackgroundResource(R.drawable.shape_button_blue);
        }
    }

   /*   @Override
   public boolean onTouch(View view, MotionEvent event) {
       int action=event.getAction();//获得触摸类型
        if(action==MotionEvent.ACTION_DOWN){//按下
            view.setBackgroundResource(R.drawable.shape_button_main);
        }else if(action==MotionEvent.ACTION_UP){
            view.setBackgroundResource(R.drawable.shape_button_main);
        }
        return false;
    }*/
}
