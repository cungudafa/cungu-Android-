package com.example.cungu.myapplication3;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.drawable.BitmapDrawable;
import android.media.Image;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.SeekBar;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.ByteBuffer;

public class imageActivity extends AppCompatActivity implements View.OnClickListener,SeekBar.OnSeekBarChangeListener{
    private ImageView iv_pic;
    private SeekBar sb_scale;
    private SeekBar sb_roaste;
    private RadioButton rb_pic1;
    private RadioButton rb_pic2;
    private RadioButton rb_pic3;
    private RadioButton rb_pic4;
    private Matrix matrix;
    private byte[] b;
    int flag=1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image);


        iv_pic=(ImageView) findViewById(R.id.iv_pic);
        sb_scale=(SeekBar) findViewById(R.id.sb_scale);
        sb_roaste=(SeekBar) findViewById(R.id.sb_roaste);
        rb_pic1=(RadioButton) findViewById(R.id.rb_pic1);
        rb_pic2=(RadioButton) findViewById(R.id.rb_pic2);
        rb_pic3=(RadioButton) findViewById(R.id.rb_pic3);
        rb_pic4=(RadioButton) findViewById(R.id.rb_pic4);
        rb_pic1.setOnClickListener(this);
        rb_pic2.setOnClickListener(this);
        rb_pic3.setOnClickListener(this);
        rb_pic4.setOnClickListener(this);
        //google网络请求
        StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder()
        .detectDiskReads().detectDiskWrites().detectNetwork()
        .penaltyLog().build());
        StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder()
        .detectLeakedSqlLiteObjects().detectLeakedClosableObjects()
        .penaltyLog().penaltyDeath().build());

        sb_scale.setOnSeekBarChangeListener(this);
        sb_roaste.setOnSeekBarChangeListener(this);

        matrix=new Matrix();
        //获得屏幕宽度
        DisplayMetrics displayMetrics=new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int screen=displayMetrics.widthPixels;
        //S设置缩放条的最大值
        sb_scale.setMax(screen);
        sb_roaste.setMax(365);

        Bitmap bitmap=BitmapFactory.decodeResource(getResources(),R.drawable.bi_xiaozhou);
        iv_pic.setImageBitmap(bitmap);
    }
    @Override
    public void onClick(View view) {
        Intent intent=new Intent();
        switch (view.getId()) {
            case R.id.rb_pic1:
                //下载图片
                String i1="https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1542541967157&di=cfd7db96f65e859ef2f79787067f0790&imgtype=0&src=http%3A%2F%2Fn.sinaimg.cn%2Fsinacn%2Fw560h360%2F20180208%2F2934-fyrkuxs4467815.jpg";
                b=downImage(i1);
                flag=1;
                //显示图片
                iv_pic.setImageBitmap(BitmapFactory.decodeByteArray(b,0,b.length));
                break;
           case R.id.rb_pic2:
                //下载图片
                String i2="https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1542543267703&di=64034ed370e5c3a933c5bc862bd99c01&imgtype=0&src=http%3A%2F%2Fpic33.photophoto.cn%2F20141108%2F0022005400165245_b.jpg";
                b=downImage(i2);
               flag=2;
                //显示图片
                iv_pic.setImageBitmap(BitmapFactory.decodeByteArray(b,0,b.length));
                break;
                case R.id.rb_pic3:
                //下载图片
                String i3="https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1542543316710&di=64d4837645e754ebbb903a177138b980&imgtype=0&src=http%3A%2F%2F5b0988e595225.cdn.sohucs.com%2Fimages%2F20180529%2F8e380858af5f47acac4f43a4fb95d1fe.jpeg";
                b=downImage(i3);
                flag=3;
                //显示图片
                iv_pic.setImageBitmap(BitmapFactory.decodeByteArray(b,0,b.length));
                break;
            case R.id.rb_pic4:
                //下载图片
                String i4="https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1543138112&di=ea84ee51a6d7c6b97b2a5a0f499345ab&imgtype=jpg&er=1&src=http%3A%2F%2Fpic36.photophoto.cn%2F20150705%2F0005018343576926_b.jpg";
                b=downImage(i4);
                flag=4;
                //显示图片
                iv_pic.setImageBitmap(BitmapFactory.decodeByteArray(b,0,b.length));
                break;
        }
    }
    /********************************************************************************
     * 自定义http协议下载图片的方法
     ********************************************************************************/
    private byte[] downImage(String i){
        ByteArrayOutputStream os =new ByteArrayOutputStream();//定义一个输出字节流
        try{
            URL url=new URL(i);
            HttpURLConnection connection=(HttpURLConnection) url.openConnection();//获得链接对象
            connection.setConnectTimeout(5000); //设置链接超时
            connection.setDoInput(true);//设置能获取服务器的响应内容
            connection.setRequestMethod("GET");//设置http的响应方式
            int code=connection.getResponseCode();  //发起请求//获取响应码状态
            if(code==200){//表示获取成功
                //获得输入流
                InputStream inputStream=connection.getInputStream();
                byte[] d=new byte[1024];
                int len;//确定读入数据的长度
                while ((len=inputStream.read(d))!=-1){
                    os.write(d,0,len);//循环写入到输出流,直到长度为-1
                }
                return os.toByteArray();
            }
        }catch (MalformedURLException e){
            e.printStackTrace();
        }catch (IOException e){
            e.printStackTrace();
        }
        return  null;
    }
    /********************************************************************************
    * SeekBar控制图片旋转&缩放
    ********************************************************************************/
    @Override
    public void onProgressChanged(SeekBar seekBar, int i, boolean bb) {
        if(seekBar.getId()==R.id.sb_scale){
            int ivWidth=i;
            int ivHeight=i*3/4;
            iv_pic.setLayoutParams(new LinearLayout.LayoutParams(ivWidth,ivHeight));
        }else if(seekBar.getId()==R.id.sb_roaste){
            //设置旋转度数
            float d=i;
            matrix.setRotate(d);
            //获取选择的图片
            // Bitmap bitmap=BitmapFactory.decodeResource(getResources(),R.drawable.bi_xiaozhou);//处理后图片赋值给新图
            // Bitmap bitmap1=bitmap.createBitmap(bitmap,0,0,bitmap.getWidth(),bitmap.getHeight(),matrix,true);
            if(flag==1)
            {
                String i1="https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1542541967157&di=cfd7db96f65e859ef2f79787067f0790&imgtype=0&src=http%3A%2F%2Fn.sinaimg.cn%2Fsinacn%2Fw560h360%2F20180208%2F2934-fyrkuxs4467815.jpg";
                b=downImage(i1);
            }
            else if(flag==2)
            {
                String i2="https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1542543267703&di=64034ed370e5c3a933c5bc862bd99c01&imgtype=0&src=http%3A%2F%2Fpic33.photophoto.cn%2F20141108%2F0022005400165245_b.jpg";
                b=downImage(i2);
            }
            else if(flag==3)
            {
                String i3="https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1542543316710&di=64d4837645e754ebbb903a177138b980&imgtype=0&src=http%3A%2F%2F5b0988e595225.cdn.sohucs.com%2Fimages%2F20180529%2F8e380858af5f47acac4f43a4fb95d1fe.jpeg";
                b=downImage(i3);
            }
            else if(flag==4)
            {
                String i4="https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1543138112&di=ea84ee51a6d7c6b97b2a5a0f499345ab&imgtype=jpg&er=1&src=http%3A%2F%2Fpic36.photophoto.cn%2F20150705%2F0005018343576926_b.jpg";
                b=downImage(i4);
            }
            Bitmap bitmap1=BitmapFactory.decodeByteArray(b,0,b.length).createBitmap(BitmapFactory.decodeByteArray(b,0,b.length),0,0,BitmapFactory.decodeByteArray(b,0,b.length).getWidth(),BitmapFactory.decodeByteArray(b,0,b.length).getHeight(),matrix,true);
            iv_pic.setImageBitmap(bitmap1);
        }
    }
    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }
    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {

    }

}
