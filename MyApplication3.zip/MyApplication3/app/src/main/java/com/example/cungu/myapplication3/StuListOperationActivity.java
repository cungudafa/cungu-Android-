package com.example.cungu.myapplication3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SimpleAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class StuListOperationActivity extends AppCompatActivity implements View.OnClickListener{
    TextView tv_title;
    Button button_add;
    Button button_send;
    AutoCompleteTextView name;
    RadioGroup rg_gender;
    Spinner major_list;
    ArrayList<StuInfo> studentList=new ArrayList<StuInfo>();
    private ArrayList<String> majors=new ArrayList<String>();
    private ArrayAdapter<String> arr_adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stu_list_operation);
        tv_title=(TextView)findViewById(R.id.tv_title);
        button_add = (Button) findViewById(R.id.button_add);
        button_send = (Button) findViewById(R.id.button_send);
        name  = (AutoCompleteTextView) findViewById(R.id.name);
        major_list = (Spinner) findViewById(R.id.major_list);

        rg_gender=(RadioGroup)findViewById(R.id.rg_gender);
        button_add.setOnClickListener(this);
        button_send.setOnClickListener(this);
        //输入时如果存在，则自动提示
        String[] arr={"易烊千玺","王俊凯","王源"};
        ArrayAdapter<String> arrayAdapter=new ArrayAdapter(this,R.layout.au_textview,arr);
        name.setAdapter(arrayAdapter);

        //获得major
        majors.add("物联网工程");
        majors.add("计算机科学");
        majors.add("通信工程  ");
        arr_adapter= new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, majors);
        //设置样式
        arr_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //加载适配器
        major_list.setAdapter(arr_adapter);

    }

    @Override
    public void onClick(View v) {
        Intent intent = new Intent();
        switch (v.getId()) {
            case R.id.button_add:
                if (name.length() == 0) {
                    name.setError("不能为空!");
                } else {
                    String n = name.getText().toString();//
                    String major = major_list.getSelectedItem().toString();//获得ListView中返回的major性别值(String类型)
                    StuInfo stu = new StuInfo(n, major);//字符串
                    studentList.add(stu);//studentList添加学生
                    if (stu != null) {
                        Toast.makeText(this, "添加完成！", Toast.LENGTH_SHORT).show();
                        return;
                    }
                }
                break;
            case R.id.button_send:
                if (studentList.isEmpty()) {
                    Toast.makeText(this, "未查询到添加数据！", Toast.LENGTH_SHORT).show();
                    return;
                }
                intent.putExtra("students", (Serializable) studentList);
                intent.setClass(this, StuAdapeterActivity.class);
                startActivity(intent);
                break;
        }
    }
    //获得RadioGroup中返回的sex性别值(String类型)
    private String getCheckedRadioInfo(RadioGroup radioGroup) {
        String sex="";
        int num=radioGroup.getChildCount();
        for(int i=0;i<num;i++){
            RadioButton rd=(RadioButton)radioGroup.getChildAt(i);
            if(rd.isChecked()){
                sex=rd.getText().toString();
                break;
            }
        }
        return sex;
    }
    //编辑学生列表中的学生信息
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (data == null) return;
        Bundle bundle = data.getExtras();
        String name1 = bundle.getString("name");
        name.setText(name1);
    }
}
