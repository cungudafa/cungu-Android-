package com.example.cungu.myapplication3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    private Button btn_calulate;
    private Button btn_movie;
    private Button btn_table;
    private Button btn_login;
    private Button btn_menu;
    private Button btn_actor;
    private Button btn_biaoqing;
    private Button btn_stu;
    private Button btn_change;
    private Button btn_image_change;
    private Button btn_imageSwitcher_change;
    private Button btn_checkbox;
    private Button btn_spinner;
    private Button btn_viewpager;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn_calulate =(Button)findViewById(R.id.btn_calulate );
        btn_movie =(Button)findViewById(R.id.btn_movie );
        btn_table =(Button)findViewById(R.id.btn_table);
        btn_login =(Button)findViewById(R.id.btn_login );
        btn_menu =(Button)findViewById(R.id.btn_menu );
        btn_actor =(Button)findViewById(R.id.btn_actor);
        btn_biaoqing =(Button)findViewById(R.id.btn_biaoqing );
        btn_stu =(Button)findViewById(R.id.btn_stu  );
        btn_change=(Button) findViewById(R.id.btn_change);
        btn_image_change=(Button) findViewById(R.id.image_change);
        btn_imageSwitcher_change=(Button)findViewById(R.id.imageSwitcher_change);
        btn_checkbox=(Button)findViewById(R.id.btn_checkbox);
        btn_spinner=(Button)findViewById(R.id.btn_spinner);
        btn_viewpager=(Button)findViewById(R.id.btn_viewpager);
        btn_calulate.setOnClickListener(this);
        btn_table.setOnClickListener(this);
        btn_movie.setOnClickListener(this);
        btn_menu.setOnClickListener(this);
        btn_login.setOnClickListener(this);
        btn_actor.setOnClickListener(this);
        btn_biaoqing.setOnClickListener(this);
        btn_stu.setOnClickListener(this);
        btn_change.setOnClickListener(this);
        btn_image_change.setOnClickListener(this);
        btn_imageSwitcher_change.setOnClickListener(this);
        btn_checkbox.setOnClickListener(this);
        btn_spinner.setOnClickListener(this);
        btn_viewpager.setOnClickListener(this);
    }
    public void onClick(View view ){
        Intent intent=new Intent();
        switch (view.getId()){
            case R.id.btn_calulate :
                intent.setClass(this,calulateActivity.class );//计算器线性1
                startActivity(intent ) ;
                break;
            case R.id.btn_movie :
                intent.setClass(this,movieActivity.class );//视频框架2
                startActivity(intent ) ;
                break;
            case R.id.btn_table :
                intent.setClass(this,TableActivity.class );//菜单3
                startActivity(intent ) ;
                break;
            case R.id.btn_login :
                intent.setClass(this,loginActivity.class );//绝对4
                startActivity(intent ) ;
                break;
            case R.id.btn_menu :
                intent.setClass(this,menuActivity.class );//菜单5
                startActivity(intent ) ;
                break;
            case R.id.btn_actor :
                intent.setClass(this,actorActivity.class );//图文混排;电影韩孝周6
                startActivity(intent ) ;
                break;
            case R.id.btn_biaoqing :
                intent.setClass(this,biaoqingActivity.class );//表情包
                startActivity(intent ) ;
                break;
            case R.id.btn_stu :
                intent.setClassName("com.example.cungu.myapplication2","com.example.cungu.myapplication2.stuActivity" );//跳转实验2,学生界面完善输入
                startActivity(intent ) ;
                break;
            case R.id.btn_change :
                intent.setClass(this,buttonActivity.class);//button变换
                startActivity(intent ) ;
                break;
            case R.id.image_change :
                intent.setClass(this,imageActivity.class );//下载图片并改变
                startActivity(intent ) ;
                break;
            case R.id.imageSwitcher_change:
                intent.setClass(this,imageSwitcherActivity.class);//图片前后查看
                startActivity(intent ) ;
                break;
            case R.id.btn_checkbox:
                intent.setClass(this,checkboxActivity.class);//投票
                startActivity(intent ) ;
                break;
            case R.id.btn_spinner:
                intent.setClass(this,StuListOperationActivity.class);//添加学生
                startActivity(intent ) ;
                break;
            case R.id.btn_viewpager:
                intent.setClass(this,ViewpagerActivity.class);//引导界面
                startActivity(intent ) ;
                break;
        }
    }
}
