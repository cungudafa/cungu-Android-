package com.example.cungu.myapplication3;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BaseAdapterActivity extends AppCompatActivity implements AdapterView.OnItemClickListener,
        AdapterView.OnItemLongClickListener{

    private ListView studentlist;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_base_adapter);

        studentlist=(ListView) findViewById(R.id.studentslist);

        initlList();
        studentlist.setOnItemClickListener(this);
        studentlist.setOnItemLongClickListener(this);

    }

    private void initlList() {
        List<Map<String,Object>> stuMaps=new ArrayList<Map<String,Object>>();
        String[] names={"易烊千玺","王源","王俊凯"};
        String[] majors={"物联网工程","计算机科学","电子工程"};
        int[] images={R.drawable.qianxi1,R.drawable.qianxi3,R.drawable.qianxi4};
        for (int i=0;i<names.length;i++){
            Map<String,Object> m=new HashMap<String,Object>();
            m.put("icon",images[i]);
            m.put("name",names[i]);
            m.put("major",majors[i]);
            stuMaps.add(m);
        }
        String[] key={"icon","name","major"};
        //int[] ids={R.id.userIcon,R.id.name,R.id.major};
        //SimpleAdapter simpleAdapter=new SimpleAdapter(this,stuMaps,R.layout.myspinner_item,key,ids);
        //studentlist.setAdapter(simpleAdapter);

        /*Map<String,Object> a1=new HashMap<String,Object>();
        a1.put("icon",R.drawable.qianxi1);
        a1.put("name","易烊千玺");
        list.add(a1);
        Map<String,Object> a2=new HashMap<String,Object>();
        a2.put("icon",R.drawable.qianxi3);
        a2.put("name","王源");
        list.add(a2);
        Map<String,Object> a3=new HashMap<String,Object>();
        a3.put("icon",R.drawable.qianxi4);
        a3.put("name","王俊凯");
        list.add(a3);
        //1上下文,2绑定的数据,3自定义样式id,4选择项的名称数组(String),5选择项名称id(int[])
        String[] key={"icon","name"};
        int[] ids={R.id.imageview,R.id.textName};
        SimpleAdapter simpleAdapter=new SimpleAdapter(this,list,R.layout.myspinner_item,key,ids);
        studentlist.setAdapter(simpleAdapter);*/
    }

    //点击项目事件
    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        ListView listView=(ListView) adapterView;
        Map<String,Object> m=(Map<String, Object>) listView.getItemAtPosition(i);//通过位置找到选项
        setTitle((CharSequence) m.get("name"));//设置layout的title
        String info=(String)m.get("name"+m.get("major"));
        Toast.makeText(this,info,Toast.LENGTH_SHORT).show();
    }
    //列表选项增加长点击事件
    @Override
    public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
        Toast.makeText(this,"查看详细信息",Toast.LENGTH_SHORT).show();
        return true;
    }
}
