package com.example.cungu.myapplication3;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.method.LinkMovementMethod;
import android.text.style.BackgroundColorSpan;
import android.text.style.ClickableSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.ImageSpan;
import android.text.style.RelativeSizeSpan;
import android.text.style.StyleSpan;
import android.text.style.SuperscriptSpan;
import android.view.View;
import android.widget.TextView;

public class actorActivity extends AppCompatActivity {
    String t1="韩孝周电影内在美女主";
    String t2="韩孝周个人主页";
    String t3="内在美电影链接";
    String t4="男主";
    String t5="导演";
    String t6="编剧";
    TextView textView1;
    TextView textView2;
    TextView textView3;
    TextView textView4;
    TextView textView5;
    TextView textView6;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actor);
        textView1 = (TextView)findViewById(R.id.textView1);
        textView2 = (TextView)findViewById(R.id.textView2);
        textView3 = (TextView)findViewById(R.id.textView3);
        textView4 = (TextView)findViewById(R.id.textView4);
        textView5 = (TextView)findViewById(R.id.textView5);
        textView6 = (TextView)findViewById(R.id.textView6);
        //===================================字体设置=============================================
        SpannableString text1=new SpannableString(t1);
        SpannableString text2=new SpannableString(t2);
        SpannableString text3=new SpannableString(t3);
        SpannableString text4=new SpannableString(t4);
        SpannableString text5=new SpannableString(t5);
        SpannableString text6=new SpannableString(t6);
        //设置前景色
        ForegroundColorSpan forcolor=new ForegroundColorSpan(Color.parseColor("#ef7a82"));
        text1.setSpan(forcolor,0,text1.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);//定位
        text2.setSpan(forcolor,0,text2.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);//定位
        text3.setSpan(forcolor,0,text3.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);//定位
        text4.setSpan(forcolor,0,text4.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);//定位
        text5.setSpan(forcolor,0,text5.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        text6.setSpan(forcolor,0,text6.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        //设置背景色
        BackgroundColorSpan back=new BackgroundColorSpan(Color.parseColor("#cca98175"));
        text1.setSpan(back,0,text1.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);//定位
        text2.setSpan(back,0,text2.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);//定位
        text3.setSpan(back,0,text3.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);//定位
        text4.setSpan(back,0,text4.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);//定位
        text5.setSpan(back,0,text5.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        text6.setSpan(back,0,text6.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        //设置文字相对大小
        RelativeSizeSpan relativeSizeSpan=new RelativeSizeSpan(1.75f);
        text1.setSpan(relativeSizeSpan,0,text1.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        text2.setSpan(relativeSizeSpan,0,text2.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        text3.setSpan(relativeSizeSpan,0,text3.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        text4.setSpan(relativeSizeSpan,0,text4.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        text5.setSpan(relativeSizeSpan,0,text6.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        text6.setSpan(relativeSizeSpan,0,text6.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        //设置上标
        SuperscriptSpan superscriptSpan=new SuperscriptSpan();
        text1.setSpan(superscriptSpan,0,3,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        //设置粗体和斜体
        StyleSpan styleSpan=new StyleSpan(Typeface.BOLD);
        StyleSpan styleSpan1=new StyleSpan(Typeface.ITALIC);
        text1.setSpan(styleSpan,0,text1.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        text1.setSpan(styleSpan1,0,text1.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        //==================================ImageSpan设置图形=====================================
        SpannableString leftString=new SpannableString("left");
        //ImageSpan imageSpan=new ImageSpan(BitmapFactory.decodeResource(getResources(),R.drawable.bi_xiaozhou));//位图;女主
        Drawable d=getResources().getDrawable(R.drawable.bi_xiaozhou);
        d.setBounds(0,0,d.getIntrinsicWidth()/7,d.getIntrinsicHeight()/7);//图片设置
        ImageSpan imageSpan=new ImageSpan(d);
        leftString.setSpan(imageSpan,0,4,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        //----------------
        SpannableString rightString_nanzhu=new SpannableString("right");
        Drawable d1=getResources().getDrawable(R.drawable.bi_nanzhu);//获得男主图片
        d1.setBounds(0,0,d1.getIntrinsicWidth()*2/3,d1.getIntrinsicHeight()*2/3);//图片设置
        ImageSpan imageSpan1=new ImageSpan(d1);
        rightString_nanzhu.setSpan(imageSpan1,0,5,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

        SpannableString rightString_daoyan=new SpannableString("right");
        Drawable d2=getResources().getDrawable(R.drawable.bi_daoyan);//获得导演图片
        d2.setBounds(0,0,d2.getIntrinsicWidth()*2/3,d2.getIntrinsicHeight()*2/3);//图片设置
        ImageSpan imageSpan2=new ImageSpan(d2);
        rightString_daoyan.setSpan(imageSpan2,0,5,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

        SpannableString rightString_bianju=new SpannableString("right");
        Drawable d3=getResources().getDrawable(R.drawable.bi_bianju);//获得编剧图片
        d3.setBounds(0,0,d3.getIntrinsicWidth()*2/3,d3.getIntrinsicHeight()*2/3);//图片设置
        ImageSpan imageSpan3=new ImageSpan(d3);
        rightString_bianju.setSpan(imageSpan3,0,5,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        /**/
        //==============================ClickableSpan点击事件======================================
        ClickableSpan clickableSpan=new ClickableSpan() {
            @Override
            public void onClick(View view) {
                Uri uri= Uri.parse("https:baike.baidu.com");
                Intent intent=new Intent();
                intent.setData(uri);
                startActivity(intent);
            }
            public void updateDrawState(TextPaint ds){
                super.updateDrawState(ds);
                ds.setColor(Color.rgb(255,255,0));//设定点击文本颜色
                ds.setUnderlineText(false);//去掉下划线
            }
        };
        text2.setSpan(clickableSpan,0,3,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);//<<韩孝周>>个人主页
        textView2.setMovementMethod(LinkMovementMethod.getInstance());
        text3.setSpan(clickableSpan,0,3,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);//<<内在美>>电影链接
        textView3.setMovementMethod(LinkMovementMethod.getInstance());
        //=====================================显示=============================================
        textView1.setText(leftString);
        textView1.append(text1);//韩孝周+图片+电影<<内在美>>女主
        textView2.setText(text2);
        textView3.setText(text3);
        //男主+图片1+导演+图片2+编剧+图片3
        textView4.setText(text4);
        textView4.append(rightString_nanzhu);
        textView4.setTextSize(15);
        textView5.setText(text5);
        textView5.append(rightString_daoyan);
        textView5.setTextSize(15);
        textView6.setText(text6);
        textView6.append(rightString_bianju);
        textView6.setTextSize(15);
    }
}
