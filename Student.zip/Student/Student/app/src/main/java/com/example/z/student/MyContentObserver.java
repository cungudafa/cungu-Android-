package com.example.z.student;

import android.database.ContentObserver;
import android.net.Uri;
import android.os.Handler;

import java.util.List;

public class MyContentObserver extends ContentObserver {
    /**
     * Creates a content observer.
     * @param handler The handler to run {@link #onChange} on, or null if none.
     */
    public MyContentObserver(Handler handler) {
        super(handler);
    }
    public void onChange(boolean selfChange,Uri uri)
    {
        String message="数据发生变化";
        android.telephony.SmsManager smsManager = android.telephony.SmsManager
                .getDefault();
        List<String> divideContents = smsManager.divideMessage(message);
        for (String text : divideContents) {
            smsManager.sendTextMessage("18523871830", null, text,null,
                    null);
        }
    }
}
