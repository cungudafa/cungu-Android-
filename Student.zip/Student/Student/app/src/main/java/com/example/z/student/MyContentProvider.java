package com.example.z.student;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;

public class MyContentProvider extends ContentProvider {
    public MySQLiteAccess MySQLiteAccess;
    private SQLiteDatabase sqLiteDatabase;
    private static UriMatcher sMatcher=new UriMatcher(UriMatcher.NO_MATCH);
    private static final int CODE_NOPARAM=1;
    private  static final int CODE_PARAM=2;
    static {
        sMatcher.addURI("com.example.z.student.MyContentProvider","stu",CODE_NOPARAM);
        sMatcher.addURI("com.example.z.student.MyContentProvider","stu/#",CODE_PARAM);
    }
    public boolean onCreate() {
       // MySQLiteAccess = new MySQLiteAccess(this.getContext());
        return false;
    }


    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        throw new IllegalArgumentException("this is unkown uri:" + uri);
    }

    @Override
    public String getType( Uri uri) {
        int matchcode=sMatcher.match(uri);
        switch(matchcode){
            case  CODE_NOPARAM:
                return "com.example.z.student.MyContentProvider/stu";
            case CODE_PARAM:
                return "com.example.z.student.MyContentProvider/stu";
            default:
                throw new IllegalArgumentException("this is unkown uri:" + uri);
        }
    }


    @Override
    public Uri insert (Uri uri,  ContentValues values) {
        int matchcode=sMatcher.match(uri);
        switch(matchcode){
            case  CODE_NOPARAM:
                // 若主键值是自增长的id值则返回值为主键值，否则为行号，但行号并不是RecNo列
                long id = sqLiteDatabase.insert("stu", null, values);
                Uri insertUri = ContentUris.withAppendedId(uri, id);
                return insertUri;
            default:
                throw new IllegalArgumentException("this is unkown uri:" + uri);
        }
    }

    @Override
    public int delete( Uri uri,  String selection, String[] selectionArgs) {
        return 0;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection,String[] selectionArgs) {
        SQLiteDatabase db = MySQLiteAccess.getWritableDatabase();
        int matchcode=sMatcher.match(uri);
        switch (matchcode)
        {
            case CODE_NOPARAM:
                return db.update("stu",values,selection, selectionArgs); // 更新所有记录
            case CODE_PARAM:
                long id = ContentUris.parseId(uri); // 取得跟在URI后面的数字
                String where = "id = " + id;
                if (null != selection && !"".equals(selection.trim()))
                {
                    where += " and " + selection;
                }
                return db.update("stu",values,where,selectionArgs);
            default:
                throw new IllegalArgumentException("this is unkown uri:" + uri);
        }
    }
}