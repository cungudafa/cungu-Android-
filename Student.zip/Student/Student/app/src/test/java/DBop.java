import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.z.student.MySQLiteAccess;
import com.example.z.student.StuInfo;

import java.util.ArrayList;
import java.util.List;

public class DBop {
    private MySQLiteAccess mySQLiteAccess;
    private SQLiteDatabase database;

    public void test(Context context){
        mySQLiteAccess=new MySQLiteAccess(context,3);
        database=mySQLiteAccess.getReadableDatabase();
    }
    public void insert(StuInfo s){
        database.execSQL("insert into students values(?,?,?)",new Object[] {s.getName(),s.getSex(),s.getAge()});
        System.out.println("插入数据成功");
    }
    public void delete(String name){
       // Integer I=new Integer(id);
        String n=new String(name);
        database.execSQL("delete from student where name=?",new Object[]{n});
    }
    public List<StuInfo> searchByName(String key){
        List<StuInfo> listByName=new ArrayList<StuInfo>();
        key="%"+key+"%";
        Cursor cursor=database.rawQuery("select * from student where name like?",new String[]{key});
        while(cursor.moveToNext()){
            int id=cursor.getInt(cursor.getColumnIndex("id"));
            String name=cursor.getString(cursor.getColumnIndex("name"));
            String sex=cursor.getString(cursor.getColumnIndex("sex"));
            String age=cursor.getString(cursor.getColumnIndex("age"));
            listByName.add(new StuInfo(name,sex,age));
        }
        return listByName;
    }

    public List<StuInfo> queryAll(){
        List<StuInfo> stus=new ArrayList<StuInfo>();
        Cursor cursor=database.rawQuery("select * from student",null);
        while(cursor.moveToNext()){
            int id=cursor.getInt(cursor.getColumnIndex("id"));
            String name=cursor.getString(cursor.getColumnIndex("name"));
            String sex=cursor.getString(cursor.getColumnIndex("sex"));
            String age=cursor.getString(cursor.getColumnIndex("age"));
            stus.add(new StuInfo(name,sex,age));
        }
        return stus;
    }

    public void update(StuInfo stu) {
        database.execSQL("update student set name=?,sex=?,age=? "
                ,new Object[] { stu.getName(), stu.getSex(), stu.getAge() });
    }

    public List<StuInfo> searchByAll(String key){
        List<StuInfo> listByAll=new ArrayList<StuInfo>();
        key="%"+key+"%";
        Cursor cursor=database.rawQuery("select * from student where  name like? or sex like? or age like?"
                ,new String[]{key,key,key});
        while(cursor.moveToNext()){
           //                                                                         int id=cursor.getInt(cursor.getColumnIndex("id"));
            String name=cursor.getString(cursor.getColumnIndex("name"));
            String sex=cursor.getString(cursor.getColumnIndex("sex"));
            String age=cursor.getString(cursor.getColumnIndex("age"));
            listByAll.add(new StuInfo(name,sex,age));
        }
        return listByAll;
    }
}
