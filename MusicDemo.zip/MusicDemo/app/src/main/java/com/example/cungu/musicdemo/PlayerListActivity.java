package com.example.cungu.musicdemo;

import android.app.Activity;

import java.io.Serializable;
import java.util.List;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

public class PlayerListActivity extends Activity implements AdapterView.OnItemLongClickListener {
    private ListView listview;
    private List<MusicInfo> musicInfos = null;
    private MusicListAdapter Listadapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player_list);
        listview = (ListView) findViewById(R.id.list);

        musicInfos = MusicUtil.getMp3Infos(PlayerListActivity.this);
        Listadapter = new MusicListAdapter(this, musicInfos);
        listview.setAdapter(Listadapter);
        listview.setOnItemLongClickListener(this);
    }

    @Override
    public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
        if (musicInfos.isEmpty()) {
            Toast.makeText(this, "未查询到歌曲！", Toast.LENGTH_SHORT).show();
        }
        Intent intent=new Intent();
        intent.putExtra("music", (Serializable) musicInfos);
        intent.setClass(this, MainActivity.class);
        startActivity(intent);
        return false;
    }
}